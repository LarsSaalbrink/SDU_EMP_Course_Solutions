

#ifndef LED_H_
#define LED_H_

void red_led_task(INT8U my_id, INT8U my_state, INT8U event, INT8U data);
void yellow_led_task(INT8U my_id, INT8U my_state, INT8U event, INT8U data);
void green_led_task(INT8U my_id, INT8U my_state, INT8U event, INT8U data);


#endif /* LED_H_ */
