/*
 * sw1.h
 *
 *  Created on: 11 Mar 2020
 *      Author: Andreas
 */

#ifndef SW1_H_
#define SW1_H_

void sw1_task(INT8U my_id, INT8U my_state, INT8U event, INT8U data);

#endif /* SW1_H_ */
